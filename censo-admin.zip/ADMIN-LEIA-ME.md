# Painel admin do censo

Painel para as atendentes verem, buscarem, editarem, cadastrarem, excluirem, importarem e exportarem os alunos.
Fica em `/admin.html` do site.

## Arquivos novos

- `admin.html`, `admin.css`, `admin.js`: tela do painel
- `api/admin.js`: servidor do painel (roda na Vercel)
- `supabase/schema.sql`: tabelas do banco

Nenhum arquivo existente do censo precisa ser alterado.

## Configuração (uma vez)

1. Crie um projeto em https://supabase.com (plano gratuito).
2. No Supabase, abra **SQL Editor**, cole o conteúdo de `supabase/schema.sql` e clique em **Run**.
3. No Supabase, abra **Project Settings > API** e copie:
   - **Project URL**
   - **service_role** (chave secreta)
4. Na Vercel, abra o projeto do censo > **Settings > Environment Variables** e crie:

   | Nome | Valor |
   |---|---|
   | `SUPABASE_URL` | Project URL do Supabase |
   | `SUPABASE_SERVICE_KEY` | chave service_role |
   | `ADMIN_PASSWORD` | senha que a equipe vai usar para entrar |
   | `ADMIN_SECRET` | texto aleatório longo (veja abaixo) |

   Para gerar o `ADMIN_SECRET`, rode no terminal:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```

5. Na Vercel, faça um novo deploy (**Deployments > Redeploy**) para as variáveis entrarem em vigor.
6. Abra `https://censo-gtech.vercel.app/admin.html`, entre com a senha e clique em **Importar**.
   Escolha `GT-Alunos-Consolidado.xlsx`. Se houver a aba **Base Completa**, ela é usada.

**Atenção:** a chave `service_role` é segredo. Ela deve ficar só nas variáveis da Vercel.
Nunca coloque ela em arquivo do projeto nem no GitHub.

## Como funciona

- **Busca e filtros:** nome, e-mail ou telefone, além de cidade, gênero, atuação em tecnologia e GT.
- **Clicar em um aluno** abre a janela de edição, com o histórico de alterações.
- **Excluir** pede confirmação antes.
- **Importar:** mostra antes quantos alunos são novos e quantos já existem. Só grava depois de confirmar.
  Um aluno é considerado repetido quando tem o mesmo nome e o mesmo e-mail ou telefone.
  Pessoas diferentes que dividem um telefone (por exemplo, familiares) entram normalmente.
  Planilhas exportadas pelo próprio painel podem ser importadas de volta.
- **Exportar:** gera uma planilha `.xlsx` com os alunos que estão na lista filtrada.
- **Sessão:** o acesso fica guardado nesta aba do navegador e expira em 12 horas. O botão **Sair** encerra na hora.
